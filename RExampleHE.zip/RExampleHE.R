library (homomorpheR)
keyPair<- PaillierKeyPair$new(modulusBits=1024)

a<-gmp::as.bigz(2173849)
#Normal Addition
d<- (a+10)
d
#Homomorphic Addition
b<- keyPair$pubkey$encrypt(a+10)
#Decryption of the result
c<- keyPair$getPrivateKey()$decrypt((b))
#Compare Normal Computation to Homomorphic Computation
identical(d,c)




