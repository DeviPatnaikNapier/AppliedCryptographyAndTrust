import sys
import  random
#from nose.tools import assert_raises
from phe import paillier
x =0
y =0 
z=0

mylist = list(range(1,101))
x= sum(mylist)
y= len(mylist)
print ("Sum: ",x)
print ("Len: ",y)
z= x/(y-1)
print ("Avge: ",z)





pub, priv = paillier.generate_paillier_keypair()
a = pub.encrypt(x)
b = pub.encrypt(1/y)
print ("Encrypted Sum:",a) 
print ("Encrypyted inverse of Len:" ,b)
c=priv.decrypt(b)
d = a * c
e=priv.decrypt(d)
print ("Decrypted Avge:", e)

